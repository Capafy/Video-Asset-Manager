# Video Asset Manager

A video project workspace with a browser-based editor and a generator-neutral
result handoff. Use it as a standalone web application or as a companion
skill in a compatible AI host.

Create a project before video generation, keep its public scripts and
reference assets together, then receive completed clips into the same
workspace for editing and export. Video generation remains the responsibility
of your chosen generator; the manager does not call video providers.

## Features

- Project and media management with clip versions, public scripts, and reports.
- A timeline editor with video, audio, subtitles, and picture-in-picture tracks.
- Clip trimming and splitting, transforms, playback speed, transitions, and
  styled text controls.
- Canvas settings, rendered video export, and project archive downloads.
- Local result intake, directory watching, and repeat-safe registration.
- Best-effort audio extraction from delivered videos, with generated provenance.
- Filesystem-based storage that keeps project data outside the application
  source directory.

## Requirements

- Python 3.10 or newer.
- FFmpeg and ffprobe available on `PATH` for rendering, media inspection,
  thumbnails, and audio extraction. Use an FFmpeg build with the `subtitles`
  filter for subtitle rendering.
- A modern browser and a writable data directory.

The bundled frontend is plain HTML, CSS, and JavaScript. No Node.js, npm
installation, frontend build, or external database is required. The Python
service uses the standard library. Provider API keys are not required by the
manager.

## Quick start

Download or clone this project and open a terminal in its root directory.
Verify the tools are available:

```sh
python --version
ffmpeg -version
ffprobe -version
```

Start the local application:

```sh
python -B assets/webapp/ensure.py open --root ../vam-data --port 4200 --bind 127.0.0.1
```

Then open [http://127.0.0.1:4200/](http://127.0.0.1:4200/) in your browser.
Use `python3` instead of `python` if that is your Python command.

`../vam-data` is an example data directory next to the repository. Replace
it with your preferred location and use the same root in all commands. The
launcher installs a runtime copy there, starts or reuses the service, and
prints a JSON result. `-B` prevents bytecode caches in the source package.

The `open` command emits a host window request; a compatible host can use it
to open or focus the management page. In a regular terminal, open the browser
URL yourself. A successful service start alone does not prove a hosted
window has opened.

For foreground operation instead of the launcher:

```sh
python -B assets/webapp/server.py --root ../vam-data --port 4200 --bind 127.0.0.1
```

Use one startup method at a time. Ctrl+C stops a foreground server. The
health endpoint is `/api/health`.

## Use as a skill

Install the complete `video-asset-manager` folder in your host's skill
directory or upload it through the host's skill installer. Keep `SKILL.md`,
`scripts/`, `assets/`, `references/`, and the accompanying license files
together; copying `SKILL.md` alone is not sufficient.

[SKILL.md](SKILL.md) defines the companion lifecycle:

1. During an actionable video-production request, prepare the project and
   register available public inputs before the generator's first operational
   question or submission.
2. Run generation through the selected generator while the management
   workspace remains available.
3. Deliver each terminal result through the completion bridge so that the
   project reflects completed, partial, or failed work.

Skill selection and automatic window opening depend on the host honoring this
contract. Discussion-only requests do not activate the production lifecycle.
If the manager is unavailable, generation must remain able to continue.

Hosted environments must provide access to port `4200` and handle the
returned window request. Do not use a container's loopback address as a URL
on a different computer.

## Receive a video

After a generator writes an output file, register it from the repository root:

```sh
python -B scripts/receive.py ../video-output/final.mp4 --root ../vam-data --task-id demo-task-001 --title "Product demo" --script "A short product reveal." --no-open
```

The example performs filesystem registration without starting another
service. The running application can display the updated project. Use
`--project <existing-slug>` to target a specific project; otherwise the
receiver can use the active project or create a project for an eligible
completed video. Keep the task ID stable when retrying the same delivery.

For JSON input, project preparation, watchers, return values, and integration
details, see the [handoff guide](scripts/README.md). The bridge handles
registration internally; an additional low-level handoff call is unnecessary.

## Project layout

```text
video-asset-manager/
  README.md                 Project overview and startup
  SKILL.md                  Host routing and workflow contract
  PUBLISHING.md             Distribution and network notes
  assets/webapp/            Web application and runtime launcher
    licenses/               Font licenses and third-party notices
  scripts/                  Intake, handoff, and project tools
    README.md               Integration guide
    tests/                  Regression tests
  references/
    project-schema.md       Project and handoff data contracts
```

Generated projects, media, logs, credentials, and runtime state do not belong
in this source tree. Keep them in the separate data/output directories.

## Network access and distribution

The quick-start commands bind to `127.0.0.1` for local access. The runtime's
default when no override is supplied is `0.0.0.0:4200`, intended for forwarded
hosting. The application has no built-in login or per-user authorization;
protect hosted access with an authenticated gateway and prevent direct
untrusted access to the port.

Read [PUBLISHING.md](PUBLISHING.md) before publishing or deploying a copy.
The five bundled fonts use OFL 1.1; retain their
[licenses and source notices](assets/webapp/licenses/README.md).
The identified snapping and edge-scrolling functions have been replaced;
their [historical source notice](assets/webapp/licenses/tooscut-NOTICE.md)
is retained. The project owner confirmed ownership of the supplied UI
template. Other implementation references and their MIT notices are listed
in the [editor source inventory](assets/webapp/licenses/editor-sources.md).
No repository-wide MIT license or blanket license clearance is implied.
